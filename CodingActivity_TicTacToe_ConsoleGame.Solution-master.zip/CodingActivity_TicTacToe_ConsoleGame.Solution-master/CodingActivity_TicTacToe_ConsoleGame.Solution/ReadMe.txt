﻿Title: Tic-Tac-Toe Game Application
Description: This application allows two users playing a simple tic-tac-toe game using the console UI. The purpose of the application to demonstrate encapsulation and the MVC design pattern.
Author: John E velis
Dated Created: 6/12/2015
Last Modified: 8/25/2016
Instructions for Use: